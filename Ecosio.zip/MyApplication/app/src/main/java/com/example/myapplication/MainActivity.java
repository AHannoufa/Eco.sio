package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_NAME = "com.example.myappliaction.example.EXTRA_NAME";
    public static final String EXTRA_EMAIL = "com.example.myappliaction.example.EXTRA_EMAIL";

    private Button btnSignUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSignUp = (Button) findViewById(R.id.btnSignUp);
        btnSignUp.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                openHomePage();

            }
        });
    }


    public void openHomePage(){
        EditText editName = (EditText)findViewById(R.id.name_Input);
        String userName = editName.getText().toString();

        EditText editEmail =(EditText)findViewById(R.id.email_Input);
        String userEmail = editEmail.getText().toString();

        Intent homeIntent = new Intent(this, HomePage.class);
        homeIntent.putExtra(EXTRA_NAME, userName);
        homeIntent.putExtra(EXTRA_EMAIL, userEmail);
        startActivity(homeIntent);
    }

}
