package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ValueAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.widget.TextView;

public class HomePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);


        Intent homeIntent = getIntent();
        String userName = homeIntent.getStringExtra(MainActivity.EXTRA_NAME);
        String userEmail = homeIntent.getStringExtra(MainActivity.EXTRA_EMAIL);

        final TextView welcomeMessage = (TextView)findViewById(R.id.txtWelcome);


        welcomeMessage.setText("Welcome to Ecosio "+userName+"!\n\n We're going to ask you a few questions...");

        final android.os.Handler handler = new android.os.Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(HomePage.this, Questionnaire.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in,R.anim.fade_out);
            }
        }, 3000);



    }







}
