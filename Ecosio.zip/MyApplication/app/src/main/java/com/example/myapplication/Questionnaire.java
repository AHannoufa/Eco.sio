package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Questionnaire extends AppCompatActivity {
    public static final String EXTRA_SCORE1 = "com.example.myapplication.example.EXTRA_SCORE1";
    public static final String EXTRA_SCORE2 = "com.example.myapplication.example.EXTRA_SCORE2";
    public static final String EXTRA_SCORE3 = "com.example.myapplication.example.EXTRA_SCORE3";
    public static final String EXTRA_SCORE4 = "com.example.myapplication.example.EXTRA_SCORE4";

    public static  int TOTAL_SCORE1=0;
    public static  int TOTAL_SCORE2=0;
    public static  int TOTAL_SCORE3=0;
    public static  int TOTAL_SCORE4=0;
    public int count=0;
    public int questionCount =0;
    public int totalCount= 0;
    public String[] optionsText = null;
    @Override
    protected void onCreate(Bundle savedInstanceState)  {

            TOTAL_SCORE1=0;
            TOTAL_SCORE2=0;
            TOTAL_SCORE3=0;
            TOTAL_SCORE4=0;

            questionCount =0;
            totalCount=0;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questionnaire);



        final TextView txtQuestion = (TextView)findViewById(R.id.txtQuestionText);
        final TextView txtQuestionNum = (TextView)findViewById(R.id.txtQuestionNum);


        String allText=null;
        try {
            allText = readFile();
        } catch (IOException e) {
            e.printStackTrace();
        }



        final String[] questionsText = getArray(allText);
            //optionsText = getOptions(allText);

        txtQuestion.setText(questionsText[questionCount]);
        txtQuestionNum.setText("Question "+(questionCount+1));

        final RadioGroup questionOptions = (RadioGroup) findViewById(R.id.rdoOptions);

        final Button nextQuestion = (Button) findViewById(R.id.btnNextQuestion);
        final RadioButton rb1 = (RadioButton) findViewById(R.id.rb1);
        final RadioButton rb2 = (RadioButton) findViewById(R.id.rb2);
        final RadioButton rb3 = (RadioButton) findViewById(R.id.rb3);
        final RadioButton rb4 = (RadioButton) findViewById(R.id.rb4);
        final RadioButton rb5 = (RadioButton) findViewById(R.id.rb5);

        rb1.setText(optionsText[questionCount]);
        rb2.setText(optionsText[questionCount+1]);
        rb3.setText(optionsText[questionCount+2]);
        rb4.setText(optionsText[questionCount+3]);
        rb5.setText(optionsText[questionCount+4]);



        rb1.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                nextQuestion.setEnabled(true);
            }
        });

        rb2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nextQuestion.setEnabled(true);
            }
        });

        rb3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nextQuestion.setEnabled(true);
            }
        });

        rb4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nextQuestion.setEnabled(true);
            }
        });

        rb5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nextQuestion.setEnabled(true);
            }
        });


        nextQuestion.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){


                totalCount++;
                if(totalCount==1){

                    if(rb1.isChecked()){
                        TOTAL_SCORE1 += 1;
                    }
                    else if(rb2.isChecked()){
                        TOTAL_SCORE1 += 2;
                    }
                    else if(rb3.isChecked()){
                        TOTAL_SCORE1 += 3;
                    }
                    else if(rb4.isChecked()){
                        TOTAL_SCORE1 +=4;
                    }
                    else if(rb5.isChecked()){
                        TOTAL_SCORE1 +=5;
                    }
                    nextQuestion.setEnabled(false);

                    txtQuestionNum.setText("");
                    txtQuestionNum.setText("Question "+(questionCount+2));

                    txtQuestion.setText(questionsText[questionCount+1]);
                    questionCount++;

                    rb1.setText(optionsText[0+5*questionCount]);
                    rb2.setText(optionsText[1+5*questionCount]);
                    rb3.setText(optionsText[2+5*questionCount]);
                    rb4.setText(optionsText[3+5*questionCount]);
                    rb5.setText(optionsText[4+5*questionCount]);
                }
                else if(totalCount==2){
                    if(rb1.isChecked()){
                        TOTAL_SCORE2 += 1;
                    }
                    else if(rb2.isChecked()){
                        TOTAL_SCORE2 += 2;
                    }
                    else if(rb3.isChecked()){
                        TOTAL_SCORE2 += 3;
                    }
                    else if(rb4.isChecked()){
                        TOTAL_SCORE2 +=4;
                    }
                    else if(rb5.isChecked()){
                        TOTAL_SCORE2 +=5;
                    }
                    nextQuestion.setEnabled(false);

                    txtQuestionNum.setText("");
                    txtQuestionNum.setText("Question "+(questionCount+2));

                    txtQuestion.setText(questionsText[questionCount+1]);
                    questionCount++;

                    rb1.setText(optionsText[0+5*questionCount]);
                    rb2.setText(optionsText[1+5*questionCount]);
                    rb3.setText(optionsText[2+5*questionCount]);
                    rb4.setText(optionsText[3+5*questionCount]);
                    rb5.setText(optionsText[4+5*questionCount]);
                }
                else if(totalCount==3){
                    if(rb1.isChecked()){
                        TOTAL_SCORE3 += 1;
                    }
                    else if(rb2.isChecked()){
                        TOTAL_SCORE3 += 2;
                    }
                    else if(rb3.isChecked()){
                        TOTAL_SCORE3 += 3;
                    }
                    else if(rb4.isChecked()){
                        TOTAL_SCORE3 +=4;
                    }
                    else if(rb5.isChecked()){
                        TOTAL_SCORE3 +=5;
                    }
                    nextQuestion.setEnabled(false);

                    txtQuestionNum.setText("");
                    txtQuestionNum.setText("Question "+(questionCount+2));

                    txtQuestion.setText(questionsText[questionCount+1]);
                    questionCount++;

                    rb1.setText(optionsText[0+5*questionCount]);
                    rb2.setText(optionsText[1+5*questionCount]);
                    rb3.setText(optionsText[2+5*questionCount]);
                    rb4.setText(optionsText[3+5*questionCount]);
                    rb5.setText(optionsText[4+5*questionCount]);
                }
                else if (totalCount == 4){
                    if(rb1.isChecked()){
                        TOTAL_SCORE4 += 1;
                    }
                    else if(rb2.isChecked()){
                        TOTAL_SCORE4 += 2;
                    }
                    else if(rb3.isChecked()){
                        TOTAL_SCORE4 += 3;
                    }
                    else if(rb4.isChecked()){
                        TOTAL_SCORE4 +=4;
                    }
                    else if(rb5.isChecked()){
                        TOTAL_SCORE4 +=5;
                    }
                        totalCount =0;
                        openResultsPage();


                        }





            }
        });
    }

    //onclick, set next question disabled, rezet text fields
    public String readFile() throws IOException {
        String allText ="";
    InputStream is = getAssets().open("Questions.txt");
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                is.close();
                allText=new String(buffer);
           return allText;
    }

    public String[] getArray(String longString){


        int count =0;

        for(int i =0;i<longString.length();i++) {
            if (longString.charAt(i)=='*'){
                count++;
            }
        }

        String[] questionText = new String[count];
        optionsText = new String[count*5];
        questionText = longString.split("\n", count*6);
        String [] finalQuestions= new String[count];
        int j =0;
        int k=0;
        for(int i=0; i<count*6;i++){
            if(questionText[i].charAt(0)=='*') {
                finalQuestions[j] = questionText[i].substring(12);
                j++;
            }
            else{
                optionsText[k] = questionText[i];
                k++;

            }

        }


        return finalQuestions;
    }

    public void openResultsPage(){


        Intent resultsIntent = new Intent(Questionnaire.this, ResultsScreen.class);

        resultsIntent.putExtra(EXTRA_SCORE1, TOTAL_SCORE1);
        resultsIntent.putExtra(EXTRA_SCORE2, TOTAL_SCORE2);
        resultsIntent.putExtra(EXTRA_SCORE3, TOTAL_SCORE3);
        resultsIntent.putExtra(EXTRA_SCORE4, TOTAL_SCORE4);
        startActivity(resultsIntent);

    }







}
