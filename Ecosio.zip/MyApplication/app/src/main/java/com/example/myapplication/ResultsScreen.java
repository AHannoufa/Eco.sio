package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ResultsScreen extends AppCompatActivity {
    public static final String BAR_SCORE1 = "com.example.myapplication.example.BAR_SCORE1";
    public static final String BAR_SCORE2 = "com.example.myapplication.example.BAR_SCORE2";
    public static final String BAR_SCORE3 = "com.example.myapplication.example.BAR_SCORE3";
    public static final String BAR_SCORE4 = "com.example.myapplication.example.BAR_SCORE4";



     int score1 = 0;
     int score2 = 0;
     int score3 = 0;
     int score4 = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
            score1 = Questionnaire.TOTAL_SCORE1;
            score2 =Questionnaire.TOTAL_SCORE2;
            score3 = Questionnaire.TOTAL_SCORE3;
            score4 = Questionnaire.TOTAL_SCORE4;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results_screen);
        Button profileButton = (Button)findViewById(R.id.MyProfileButton);

        profileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent barsScreen = new Intent(ResultsScreen.this, BarsScreen.class);
                barsScreen.putExtra(BAR_SCORE1, score1);
                barsScreen.putExtra(BAR_SCORE2, score2);
                barsScreen.putExtra(BAR_SCORE3, score3);
                barsScreen.putExtra(BAR_SCORE4, score4);

                startActivity(barsScreen);
            }
        });


    TextView Goal1 = (TextView) findViewById(R.id.Goal1);

   if (score1 >= 3){
        Goal1.setText("You should walk more to reduce your carbon emissions while traveling!");
    }
   else{
        Goal1.setText("You're already reducing carbon emissions when traveling, Good Job!");
    }



    TextView Goal2 = (TextView) findViewById(R.id.Goal2);

   if (score2 >= 3){
        Goal2.setText("Take shorter showers to reduce water consumption!");
    }
   else {
        Goal2.setText("You're already reducing your water consumption, Good Job!");
    }



    TextView Goal3 = (TextView) findViewById(R.id.Goal3);

    if (score3 >= 3){
        Goal3.setText("Use fewer devices at a time!");
    }
   else if (score3 < 3){
        Goal3.setText("You're already reducing your energy consumption, Good Job!");
    }


    TextView Goal4 = (TextView) findViewById(R.id.Goal4);

   if (score4 >= 3){
        Goal4.setText("You should recycle more!");
    }
   else if(score4 < 3){
        Goal4.setText("You're already doing a great job recycling!");
    }


}


}
