package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.myapplication.R;

public class SeeRewards extends AppCompatActivity {
    TextView points =null;
    ProgressBar pBar = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        points = (TextView) findViewById(R.id.points);

        int x = 100;

        points.setText(Integer.toString(x));

         pBar= (ProgressBar) findViewById(R.id.pBar);
        pBar.setMax(100);
        if (x == 0) {
            pBar.setProgress(0);
        }
        else if (x > 0 && x <= 10){
            pBar.setProgress(10);}

        else if (x > 10 && x <= 20){
            pBar.setProgress(20);}

        else if (x > 20 && x <= 30)
            pBar.setProgress(30);
        else if (x > 30 && x <= 40)
            pBar.setProgress(40);
        else if (x > 40 && x <= 50)
            pBar.setProgress(50);
        else if (x > 50 && x <= 60)
            pBar.setProgress(60);
        else if (x > 60 && x <= 70)
            pBar.setProgress(70);
        else if (x > 70 && x <= 80)
            pBar.setProgress(80);
        else if (x > 80 && x <= 90)
            pBar.setProgress(90);
        else if (x > 90 && x <= 99)
            pBar.setProgress(99);
        else if (x > 99 && x <= 100)
            pBar.setProgress(100);


        ImageButton prize1 = (ImageButton) findViewById(R.id.prize1);
        prize1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView points = (TextView) findViewById(R.id.points);
                int current = Integer.parseInt(points.getText().toString());
                if(current - 25 < 0) {
                    openSpeech();
                }
                else{
                    String y = Integer.toString(current - 25);
                    points.setText(y);
                    openDialog();
                    int x = Integer.parseInt(y);
                    ProgressBar pBar = (ProgressBar) findViewById(R.id.pBar);

                    if (x == 0)
                        pBar.setProgress(0);
                    else if (x > 0 && x <= 10)
                        pBar.setProgress(10);
                    else if (x > 10 && x <= 20)
                        pBar.setProgress(20);
                    else if (x > 20 && x <= 30)
                        pBar.setProgress(30);
                    else if (x > 30 && x <= 40)
                        pBar.setProgress(40);
                    else if (x > 40 && x <= 50)
                        pBar.setProgress(50);
                    else if (x > 50 && x <= 60)
                        pBar.setProgress(60);
                    else if (x > 60 && x <= 70)
                        pBar.setProgress(70);
                    else if (x > 70 && x <= 80)
                        pBar.setProgress(80);
                    else if (x > 80 && x <= 90)
                        pBar.setProgress(90);
                    else if (x > 90 && x <= 99)
                        pBar.setProgress(99);
                    else if (x > 99 && x <= 100)
                        pBar.setProgress(100);

                }

            }
        });

        ImageButton prize2 = (ImageButton) findViewById(R.id.prize2);
        prize2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView points = (TextView) findViewById(R.id.points);
                int current = Integer.parseInt(points.getText().toString());
                if(current - 35 < 0) {
                    openSpeech();
                }
                else{
                    String y = Integer.toString(current - 35);
                    points.setText(y);
                    openDialog();
                    int x = Integer.parseInt(y);
                    ProgressBar pBar = (ProgressBar) findViewById(R.id.pBar);

                    if (x == 0)
                        pBar.setProgress(0);
                    else if (x > 0 && x <= 10)
                        pBar.setProgress(10);
                    else if (x > 10 && x <= 20)
                        pBar.setProgress(20);
                    else if (x > 20 && x <= 30)
                        pBar.setProgress(30);
                    else if (x > 30 && x <= 40)
                        pBar.setProgress(40);
                    else if (x > 40 && x <= 50)
                        pBar.setProgress(50);
                    else if (x > 50 && x <= 60)
                        pBar.setProgress(60);
                    else if (x > 60 && x <= 70)
                        pBar.setProgress(70);
                    else if (x > 70 && x <= 80)
                        pBar.setProgress(80);
                    else if (x > 80 && x <= 90)
                        pBar.setProgress(90);
                    else if (x > 90 && x <= 99)
                        pBar.setProgress(99);
                    else if (x > 99 && x <= 100)
                        pBar.setProgress(100);

                }

            }
        });
        ImageButton prize3 = (ImageButton) findViewById(R.id.prize3);
        prize3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView points = (TextView) findViewById(R.id.points);
                int current = Integer.parseInt(points.getText().toString());
                if(current - 60 < 0) {
                    openSpeech();
                }
                else{
                    String y = Integer.toString(current - 60);
                    points.setText(y);
                    openDialog();
                    int x = Integer.parseInt(y);
                    ProgressBar pBar = (ProgressBar) findViewById(R.id.pBar);

                    if (x == 0)
                        pBar.setProgress(0);
                    else if (x > 0 && x <= 10)
                        pBar.setProgress(10);
                    else if (x > 10 && x <= 20)
                        pBar.setProgress(20);
                    else if (x > 20 && x <= 30)
                        pBar.setProgress(30);
                    else if (x > 30 && x <= 40)
                        pBar.setProgress(40);
                    else if (x > 40 && x <= 50)
                        pBar.setProgress(50);
                    else if (x > 50 && x <= 60)
                        pBar.setProgress(60);
                    else if (x > 60 && x <= 70)
                        pBar.setProgress(70);
                    else if (x > 70 && x <= 80)
                        pBar.setProgress(80);
                    else if (x > 80 && x <= 90)
                        pBar.setProgress(90);
                    else if (x > 90 && x <= 99)
                        pBar.setProgress(99);
                    else if (x > 99 && x <= 100)
                        pBar.setProgress(100);

                }

            }
        });


        ImageButton prize4 = (ImageButton) findViewById(R.id.prize4);
        prize4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView points = (TextView) findViewById(R.id.points);
                int current = Integer.parseInt(points.getText().toString());
                if(current - 85 < 0) {
                    openSpeech();
                }
                else{
                    String y = Integer.toString(current - 85);
                    points.setText(y);
                    openDialog();
                    int x = Integer.parseInt(y);
                    ProgressBar pBar = (ProgressBar) findViewById(R.id.pBar);

                    if (x == 0)
                        pBar.setProgress(0);
                    else if (x > 0 && x <= 10)
                        pBar.setProgress(10);
                    else if (x > 10 && x <= 20)
                        pBar.setProgress(20);
                    else if (x > 20 && x <= 30)
                        pBar.setProgress(30);
                    else if (x > 30 && x <= 40)
                        pBar.setProgress(40);
                    else if (x > 40 && x <= 50)
                        pBar.setProgress(50);
                    else if (x > 50 && x <= 60)
                        pBar.setProgress(60);
                    else if (x > 60 && x <= 70)
                        pBar.setProgress(70);
                    else if (x > 70 && x <= 80)
                        pBar.setProgress(80);
                    else if (x > 80 && x <= 90)
                        pBar.setProgress(90);
                    else if (x > 90 && x <= 99)
                        pBar.setProgress(99);
                    else if (x > 99 && x <= 100)
                        pBar.setProgress(100);

                }

            }
        });



    }





    public void openDialog(){
        confirmation dialog = new confirmation();
        dialog.show(getSupportFragmentManager(), "dialog");






    }
    public void openSpeech(){
        rejection dialog = new rejection();
        dialog.show(getSupportFragmentManager(), "dialog");

    }

}