package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class BarsScreen extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        int x = 0;
        if(Questionnaire.TOTAL_SCORE1 == 1){
            x=100;
        }
        else{
            x= 100-Questionnaire.TOTAL_SCORE1*20;
        }

        int y = 0;
        if(Questionnaire.TOTAL_SCORE2 == 1){
            y=100;
        }
        else{
            y= 100-Questionnaire.TOTAL_SCORE2*20;
        }


        int z = 0;
        if(Questionnaire.TOTAL_SCORE3 == 1){
            z=100;
        }
        else{
            z= 100-Questionnaire.TOTAL_SCORE3*20;
        }

        int a= 0;
        if(Questionnaire.TOTAL_SCORE4 == 1){
            a=100;
        }
        else{
            a= 100-Questionnaire.TOTAL_SCORE4*20;
        }


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bars_screen);


        ProgressBar pBar1 = (ProgressBar) findViewById(R.id.pBar1);
        pBar1.setMax(100);

        TextView pText1 = (TextView) findViewById(R.id.pText1);

        if (x == 0){
            pBar1.setProgress(0);
            pText1.append(x + "%");
        }
        else if (x > 0 && x <= 10){
            pBar1.setProgress(10);
            pText1.append(x + "%");
        }
        else if (x > 10 && x <= 20){
            pBar1.setProgress(20);
            pText1.append(x + "%");
        }
        else if (x > 20 && x <= 30){
            pBar1.setProgress(30);
            pText1.append(x + "%");
        }
        else if (x > 30 && x <= 40){
            pBar1.setProgress(40);
            pText1.append(x + "%");
        }
        else if (x > 40 && x <= 50){
            pBar1.setProgress(50);
            pText1.append(x + "%");
        }
        else if (x > 50 && x <= 60){
            pBar1.setProgress(60);
            pText1.append(x + "%");
        }
        else if (x > 60 && x <= 70){
            pBar1.setProgress(70);
            pText1.append(x + "%");
        }
        else if (x > 70 && x <= 80){
            pBar1.setProgress(80);
            pText1.append(x + "%");
        }
        else if (x > 80 && x <= 90){
            pBar1.setProgress(90);
            pText1.append(x + "%");
        }
        else if (x > 90 && x <= 99){
            pBar1.setProgress(99);
            pText1.append(x + "%");
        }
        else if (x > 99 && x <= 100){
            pBar1.setProgress(100);
            pText1.append(x + "%");
        }





        ProgressBar pBar2 = (ProgressBar) findViewById(R.id.pBar2);
        pBar2.setMax(100);

        TextView pText2 = (TextView) findViewById(R.id.pText2);

        if (y == 0){
            pBar2.setProgress(0);
            pText2.append(y + "%");
        }
        else if (y > 0 && y <= 10){
            pBar2.setProgress(10);
            pText2.append(y + "%");
        }
        else if (y > 10 && y <= 20){
            pBar2.setProgress(20);
            pText2.append(y + "%");
        }
        else if (y > 20 && y <= 30){
            pBar2.setProgress(30);
            pText2.append(y + "%");
        }
        else if (y > 30 && y <= 40){
            pBar2.setProgress(40);
            pText2.append(y + "%");
        }
        else if (y > 40 && y <= 50){
            pBar2.setProgress(50);
            pText2.append(y + "%");
        }
        else if (y > 50 && y <= 60){
            pBar2.setProgress(60);
            pText2.append(y + "%");
        }
        else if (y > 60 && y <= 70){
            pBar2.setProgress(70);
            pText2.append(y + "%");
        }
        else if (y > 70 && y <= 80){
            pBar2.setProgress(80);
            pText2.append(y + "%");
        }
        else if (y > 80 && y <= 90){
            pBar2.setProgress(90);
            pText2.append(y + "%");
        }
        else if (y > 90 && y <= 99){
            pBar2.setProgress(99);
            pText2.append(y + "%");
        }
        else if (y > 99 && y <= 100){
            pBar2.setProgress(100);
            pText2.append(y + "%");
        }




        ProgressBar pBar3 = (ProgressBar) findViewById(R.id.pBar3);
        pBar3.setMax(100);

        TextView pText3 = (TextView) findViewById(R.id.pText3);

        if (z == 0){
            pBar3.setProgress(0);
            pText3.append(z + "%");
        }
        else if (z > 0 && z <= 10){
            pBar3.setProgress(10);
            pText3.append(z + "%");
        }
        else if (z > 10 && z <= 20){
            pBar3.setProgress(20);
            pText3.append(z + "%");
        }
        else if (z > 20 && z <= 30){
            pBar3.setProgress(30);
            pText3.append(z + "%");
        }
        else if (z > 30 && z <= 40){
            pBar3.setProgress(40);
            pText3.append(z + "%");
        }
        else if (z > 40 && z <= 50){
            pBar3.setProgress(50);
            pText3.append(z + "%");
        }
        else if (z > 50 && z <= 60){
            pBar3.setProgress(60);
            pText3.append(z + "%");
        }
        else if (z > 60 && z <= 70){
            pBar3.setProgress(70);
            pText3.append(z + "%");
        }
        else if (z > 70 && z <= 80){
            pBar3.setProgress(80);
            pText3.append(z + "%");
        }
        else if (z > 80 && z <= 90){
            pBar3.setProgress(90);
            pText3.append(z + "%");
        }
        else if (z > 90 && z <= 99){
            pBar3.setProgress(99);
            pText3.append(z + "%");
        }
        else if (z > 99 && z <= 100){
            pBar3.setProgress(100);
            pText3.append(z + "%");
        }





        ProgressBar pBar4 = (ProgressBar) findViewById(R.id.pBar4);
        pBar4.setMax(100);

        TextView pText4 = (TextView) findViewById(R.id.pText4);

        if (a == 0){
            pBar4.setProgress(0);
            pText4.append(a + "%");
        }
        else if (a > 0 && a <= 10){
            pBar4.setProgress(10);
            pText4.append(a + "%");
        }
        else if (a > 10 && a <= 20){
            pBar4.setProgress(20);
            pText4.append(a + "%");
        }
        else if (a > 20 && a <= 30){
            pBar4.setProgress(30);
            pText4.append(a + "%");
        }
        else if (a > 30 && a <= 40){
            pBar4.setProgress(40);
            pText4.append(a + "%");
        }
        else if (a > 40 && a <= 50){
            pBar4.setProgress(50);
            pText4.append(a + "%");
        }
        else if (a > 50 && a <= 60){
            pBar4.setProgress(60);
            pText4.append(a + "%");
        }
        else if (a > 60 && a <= 70){
            pBar4.setProgress(70);
            pText4.append(a + "%");
        }
        else if (a > 70 && a <= 80){
            pBar4.setProgress(80);
            pText4.append(a + "%");
        }
        else if (a > 80 && a <= 90){
            pBar4.setProgress(90);
            pText4.append(a + "%");
        }
        else if (a > 90 && a <= 99){
            pBar4.setProgress(99);
            pText4.append(a + "%");
        }
        else if (a > 99 && a <= 100){
            pBar4.setProgress(100);
            pText4.append(a + "%");
        }

        Button btnSeeRewards = (Button)findViewById((R.id.btnSeeRewards));
        Button btnReadArticles = (Button)findViewById((R.id.btnReadArticles));
        btnSeeRewards.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });

    }

    public void onButtonClick(View v){
        Intent myIntent = new Intent(getBaseContext(),   SeeRewards.class);
        startActivity(myIntent);
    }
}
